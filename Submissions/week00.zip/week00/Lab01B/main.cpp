/* CSCI 261 Lab 01A: I/O 101 (_GIVE_BRIEF_DESCRIPTION_HERE_)
*
* Author: Calvin Mak (_INSERT_YOUR_NAME_HERE_)
*
* More complete description here...
Investigating how output in C++
*/

// The include section adds extra definitions from the C++ standard library.
#include <iostream> // For cin, cout, etc.
// We will (most of the time) use the standard library namespace in our programs.
using namespace std;

// Define any constants or global variables below this comment.

// Must have a function named "main", which is the starting point of a C++ program.
int main() {

    /******** INSERT YOUR CODE BELOW HERE ********/
    cout << "   *\n  ***\n *****\n*******\n  ***\n";
    cout << endl << endl;
    cout << "/\\   /\\\n";
    cout << "  o o\n";
    cout << " =   =\n";
    cout << "  ---\n";
    /******** INSERT YOUR CODE ABOVE HERE ********/

    return 0; // signals the operating system that our program ended OK.
}