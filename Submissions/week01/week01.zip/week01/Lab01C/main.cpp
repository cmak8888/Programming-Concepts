/* CSCI 261 Lab 01C: GEOMETRIC CALCULATIONS
*
* Author: Calvin Mak (_INSERT_YOUR_NAME_HERE_)
*
* Add more complete description here...
Investigate the use of cout, cin, and declaring variables and constants
*/

// The include section adds extra definitions from the C++ standard library.
#include <iostream> // For cin, cout, etc.
#include <cmath>
// We will (most of the time) use the standard library namespace in our programs.
using namespace std;

// Must have a function named "main", which is the starting point of a C++ program.
int main() {

    /******** MODIFY OR INSERT CODE BELOW HERE ********/
    cout << "Enter integer dimensions (Whole Numbers)" << endl;
    int length, width, height, volume;
    double radius, area;
    const double PI = 3.14159;
    cout << "Enter length of Prism: ";
    cin >> length;
    cout << "\nEnter width of Prism: ";
    cin >> width;
    cout << "\nEnter height of Prism: ";
    cin >> height;
    volume = length * width * height;
    cout << "\nYour acquired volume of prism is " << volume << " units^3.";

    cout << "\nInput Radius: ";
    cin >> radius;
    // Area of a Circle is radius^2 * PI
    area = PI* pow(radius,2);
    cout << endl << "Your acquired circle area is " << area << " units^2" << endl;
    /******** MODIFY OR INSERT CODE ABOVE HERE ********/

    return 0; // signals the operating system that our program ended OK.
}
