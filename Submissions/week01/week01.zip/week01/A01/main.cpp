/* CSCI 261 Assignment 01: Hello World and ASCII Art
*
* Author: Calvin Mak (_INSERT_YOUR_NAME_HERE_)
*
* Investigating how cin and cout works in C++
*/

// The include section adds extra definitions from the C++ standard library.
#include <iostream> // For cin, cout, etc.
#include <string>
// We will (most of the time) use the standard library namespace in our programs.
using namespace std;

// Define any constants or global variables below this comment.

// Must have a function named "main", which is the starting point of a C++ program.
int main() {

    /******** INSERT YOUR CODE BELOW HERE ********/
    int myAge;                                                              //initialize variables for Part 2
    string name, school;
    /*                              Assignment 01 Part 1                    */
        cout << "              **                      **" << endl;
    cout << "          ** **** **              ** **** ** " << endl;
    cout << "            **  **                  **  ** " << endl;
    cout << "           " << endl << endl << endl;
    cout << "       ****                                ****" << endl;
    cout << "       ****                                ****" << endl;
    cout << "        ****                              **** " << endl;
    cout << "          *****                         *****  " << endl;
    cout << "            *******************************    " << endl;
    cout << "              ***************************     " << endl;
    cout << "                " << endl << endl;

    /*                              Assignment 02 Part 2                     */
    
    name = "Calvin";                                                // declares name
    school = "School of Mines";                                     // declares school
    myAge = 19;                                                     // declares myAge
    cout << "Hello World!" << endl;                                 // Prints statements
    cout << "My name is " << name << "." << endl;
    cout << "I am " << myAge << " years old!" << endl;
    cout << "I go to " << school << "." << endl;
    cout << "Goodbye!" << endl;
    /******** INSERT YOUR CODE ABOVE HERE ********/

    return 0; // signals the operating system that our program ended OK.
}